'use strict';
// LiteSpeed (cPanel) loads Node.js apps via require() which can't handle ESM top-level await.
// This CJS wrapper uses dynamic import() to bridge the gap.
import('./src/index.js').catch(err => {
  console.error('[STARTUP ERROR]', err);
  process.exit(1);
});
